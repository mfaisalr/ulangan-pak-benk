<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/elvis/elvis/multi-page/index16.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Nov 2019 16:25:49 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Alumni SMP</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="../img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="../css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="../css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="../css/animate.min.css">
    <!-- Font-awesome CSS-->
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <!-- Flaticon CSS-->
    <link rel="stylesheet" type="text/css" href="../css/font/flaticon.css">
    <!-- Owl Caousel CSS -->
    <link rel="stylesheet" href="../vendor/OwlCarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="../vendor/OwlCarousel/owl.theme.default.min.css">
    <!-- Slick Caousel CSS -->
    <link rel="stylesheet" href="../vendor/slick/slick.css">
    <link rel="stylesheet" href="../vendor/slick/slick-theme.css">
    <!-- Main Menu CSS -->
    <link rel="stylesheet" href="../css/meanmenu.min.css">
    <!-- nivo slider CSS -->
    <link rel="stylesheet" href="../vendor/slider/css/nivo-slider.css" type="text/css" />
    <link rel="stylesheet" href="../vendor/slider/css/preview.css" type="text/css" media="screen" />
    <!-- Datetime Picker Style CSS -->
    <link rel="stylesheet" href="../css/jquery.datetimepicker.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" type="text/css" href="../css/magnific-popup.css">
    <!-- Switch Style CSS -->
    <link rel="stylesheet" href="../css/hover-min.css">
    <!-- Switch Style CSS -->
    <link rel="stylesheet" href="../css/switch-style.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../style.css">
    <!-- Modernizr Js -->
    <script src="../js/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- Add your site or application content here -->
    <div id="wrapper">
        <!-- Header Area Start Here -->
        <header>
            <div id="header-one" class="header-area header-fixed header-style-four">
                <div class="main-menu-area bg-light" id="sticker">
                    <div class="container container-fluid-sm">
                        <div class="row no-gutters d-flex align-items-center">
                            <div class="col-lg-3 col-md-3">
                                <div class="logo-area">
                                    <a href="index.html" class="logo-dark"><span>A</span> SMP ?</a>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-8 possition-static">
                                <div class="elv-main-menu">
                                    <nav>
                                        <ul>
                                            <li class="menu-justify current"><a href="#">Home</a>
                                                <div class="rt-dropdown-mega container">
                                                    <div class="rt-dropdown-inner">
                                                        <div class="row">
                                                            <div class="col-sm-3">
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="index.html">Agency 1</a></li>
                                                                    <li><a href="index2.html">Agency 2</a></li>
                                                                    <li><a href="index3.html">Business 1</a></li>
                                                                    <li><a href="index4.html">Business 2</a></li>
                                                                    <li><a href="index5.html">Business 3</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="index6.html">Portfolio 1</a></li>
                                                                    <li><a href="index7.html">Portfolio 2</a></li>
                                                                    <li><a href="index8.html">Corporate</a></li>
                                                                    <li><a href="index9.html">Corporate/Finance</a></li>
                                                                    <li><a href="index10.html">Construction</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="index11.html">Creative</a></li>
                                                                    <li><a href="index12.html">Repair service</a></li>
                                                                    <li><a href="index13.html">Medical</a></li>
                                                                    <li><a href="index14.html">Restaurant</a></li>
                                                                    <li><a href="index15.html">law</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <ul class="rt-mega-items">
                                                                    <li class="current"><a href="index16.html">Seo Company</a></li>
                                                                    <li><a href="index17.html">App Landing</a></li>
                                                                    <li><a href="index18.html">Tourism</a></li>
                                                                    <li><a href="index19.html">Music</a></li>
                                                                    <li><a href="index20.html">Photography</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li><a href="#">About</a>
                                                <ul class="rt-dropdown-menu">
                                                    <li><a href="about1.html">About 1</a></li>
                                                    <li><a href="about2.html">About 2</a></li>
                                                    <li><a href="about3.html">About 3</a></li>
                                                    <li><a href="about4.html">About 4</a></li>
                                                    <li><a href="about5.html">About 5</a></li>
                                                    <li><a href="about6.html">About 6</a></li>
                                                    <li><a href="about7.html">About 7</a></li>
                                                    <li><a href="about8.html">About 8</a></li>
                                                </ul>
                                            </li>
                                            <li class="menu-justify"><a href="#">Pages</a>
                                                <div class="rt-dropdown-mega container">
                                                    <div class="rt-dropdown-inner">
                                                        <div class="row">
                                                            <div class="col-sm-3">
                                                                <div class="menu-layout-title">About Layout</div>
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="about1.html">About 1</a></li>
                                                                    <li><a href="about2.html">About 2</a></li>
                                                                    <li><a href="about3.html">About 3</a></li>
                                                                    <li><a href="about4.html">About 4</a></li>
                                                                    <li><a href="about5.html">About 5</a></li>
                                                                    <li><a href="about6.html">About 6</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <div class="menu-layout-title">About Layout</div>
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="about7.html">About 7</a></li>
                                                                    <li><a href="about8.html">About 8</a></li>
                                                                </ul>
                                                                <div class="menu-layout-title mt-13">Shop Layout</div>
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="shop1.html">Shop 1</a></li>
                                                                    <li><a href="shop2.html">Shop 2</a></li>
                                                                    <li><a href="single-shop.html">Shop Details</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <div class="menu-layout-title">Portfolio Layout</div>
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="portfolio1.html">Portfolio 1</a></li>
                                                                    <li><a href="portfolio2.html">Portfolio 2</a></li>
                                                                    <li><a href="portfolio3.html">Portfolio 3</a></li>
                                                                    <li><a href="portfolio4.html">Portfolio 4</a></li>
                                                                    <li><a href="portfolio5.html">Portfolio 5</a></li>
                                                                    <li><a href="single-portfolio.html">Portfolio Details</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-sm-3">
                                                                <div class="menu-layout-title">Other Layout</div>
                                                                <ul class="rt-mega-items">
                                                                    <li><a href="login-registration.html">Login Registration</a></li>
                                                                    <li><a href="wishlist.html">Wishlist</a></li>
                                                                    <li><a href="cart.html">Cart</a></li>
                                                                    <li><a href="check-out.html">Check Out</a></li>
                                                                    <li><a href="contact.html">Contact</a></li>
                                                                    <li><a href="404.html">404 Error</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li><a href="#">Services</a>
                                                <ul class="rt-dropdown-menu">
                                                    <li><a href="service1.html">Service 1</a></li>
                                                    <li><a href="service2.html">Service 2</a></li>
                                                    <li><a href="service3.html">Service 3</a></li>
                                                    <li><a href="service4.html">Service 4</a></li>
                                                    <li><a href="service5.html">Service 5</a></li>
                                                    <li><a href="single-service.html">Single Service</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">Portfolio</a>
                                                <ul class="rt-dropdown-menu">
                                                    <li><a href="portfolio1.html">Portfolio 1</a></li>
                                                    <li><a href="portfolio2.html">Portfolio 2</a></li>
                                                    <li><a href="portfolio3.html">Portfolio 3</a></li>
                                                    <li><a href="portfolio4.html">Portfolio 4</a></li>
                                                    <li><a href="portfolio5.html">Portfolio 5</a></li>
                                                    <li><a href="single-portfolio.html">Portfolio Details</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">Blog</a>
                                                <ul class="rt-dropdown-menu">
                                                    <li><a href="blog1.html">Blog 1</a></li>
                                                    <li><a href="blog2.html">Blog 2</a></li>
                                                    <li><a href="blog3.html">Blog 3</a></li>
                                                    <li><a href="blog4.html">Blog 4</a></li>
                                                    <li><a href="single-blog.html">Blog Details</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">Shop</a>
                                                <ul class="rt-dropdown-menu">
                                                    <li><a href="shop1.html">Shop 1</a></li>
                                                    <li><a href="shop2.html">Shop 2</a></li>
                                                    <li><a href="single-shop.html">Shop Details</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="contact.html">Contact</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                <ul class="nav-top-right posiition4">
                                <div class="slider-btn-area slider-btn-left">
                                    <div class="top-right links">
                                            <a href="{{ route('register') }}" class="btn-ftf-rd-sm-p-dp">Register</a>
                                    </div>
                                </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu Area Start -->
            {{-- <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul>
                                        <li><a href="#">Home</a>
                                            <ul>
                                                <li><a href="index.html">Agency 1</a></li>
                                                <li><a href="index2.html">Agency 2</a></li>
                                                <li><a href="index3.html">Business 1</a></li>
                                                <li><a href="index4.html">Business 2</a></li>
                                                <li><a href="index5.html">Business 3</a></li>
                                                <li><a href="index6.html">Portfolio 1</a></li>
                                                <li><a href="index7.html">Portfolio 2</a></li>
                                                <li><a href="index8.html">Corporate</a></li>
                                                <li><a href="index9.html">Corporate/Finance</a></li>
                                                <li><a href="index10.html">Construction</a></li>
                                                <li><a href="index11.html">Creative</a></li>
                                                <li><a href="index12.html">Repair service</a></li>
                                                <li><a href="index13.html">Medical</a></li>
                                                <li><a href="index14.html">Restaurant</a></li>
                                                <li><a href="index15.html">law</a></li>
                                                <li><a href="index16.html">Seo Company</a></li>
                                                <li><a href="index17.html">App Landing</a></li>
                                                <li><a href="index18.html">Tourism</a></li>
                                                <li><a href="index19.html">Music</a></li>
                                                <li><a href="index20.html">Photography</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">About Us</a>
                                            <ul>
                                                <li><a href="about1.html">About 1</a></li>
                                                <li><a href="about2.html">About 2</a></li>
                                                <li><a href="about3.html">About 3</a></li>
                                                <li><a href="about4.html">About 4</a></li>
                                                <li><a href="about5.html">About 5</a></li>
                                                <li><a href="about6.html">About 6</a></li>
                                                <li><a href="about7.html">About 7</a></li>
                                                <li><a href="about8.html">About 8</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Shop</a>
                                            <ul>
                                                <li><a href="shop1.html">Shop 1</a></li>
                                                <li><a href="shop2.html">Shop 2</a></li>
                                                <li><a href="single-shop.html">Shop Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Portfolio</a>
                                            <ul>
                                                <li><a href="portfolio1.html">Portfolio 1</a></li>
                                                <li><a href="portfolio2.html">Portfolio 2</a></li>
                                                <li><a href="portfolio3.html">Portfolio 3</a></li>
                                                <li><a href="portfolio4.html">Portfolio 4</a></li>
                                                <li><a href="portfolio5.html">Portfolio 5</a></li>
                                                <li><a href="single-portfolio.html">Portfolio Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Service</a>
                                            <ul>
                                                <li><a href="service1.html">Service 1</a></li>
                                                <li><a href="service2.html">Service 2</a></li>
                                                <li><a href="service3.html">Service 3</a></li>
                                                <li><a href="service4.html">Service 4</a></li>
                                                <li><a href="service5.html">Service 5</a></li>
                                                <li><a href="single-service.html">Single Service</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Blog</a>
                                            <ul>
                                                <li><a href="blog1.html">Blog 1</a></li>
                                                <li><a href="blog2.html">Blog 2</a></li>
                                                <li><a href="blog3.html">Blog 3</a></li>
                                                <li><a href="blog4.html">Blog 4</a></li>
                                                <li><a href="single-blog.html">Blog Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Pages</a>
                                            <ul>
                                                <li><a href="login-registration.html">Login Registration</a></li>
                                                <li><a href="wishlist.html">Wishlist</a></li>
                                                <li><a href="cart.html">Cart</a></li>
                                                <li><a href="check-out.html">Check Out</a></li>
                                                <li><a href="404.html">404 Error</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu Area End --> --}}
        </header>
        <!-- Header Area End Here -->
        <!-- Slider Area Start Here -->
        <div class="slider-area slider-mt">
            <div class="bend niceties preview-1">
                <div id="ensign-nivoslider-3" class="slides">
                    <img src="img/slider/slide-14-1.jpg" alt="slider" title="#slider-direction-1" />
                    <img src="img/slider/slide-14-2.jpg" alt="slider" title="#slider-direction-2" />
                </div>
                <div id="slider-direction-1" class="t-cn slider-direction">
                    <div class="slider-content s-tb slide-1">
                        <div class="title-container s-tb-c title-dark">
                            <div class="container text-left title-double-line">
                                <p class="slider-big-text">Pendataan Alumni SMP</p>
                                <p class="slider-sub-text para-padding-right">Silahkan daftar sebagai alumni smp ?, jika anda lulusan smp ?</p>
                                @if (Route::has('login'))
                                <div class="slider-btn-area slider-btn-left">
                                    <div class="top-right links">
                                            <a href="{{ route('login') }}" class="btn-ftf-rd-sm-p-dp">Login</a>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div id="slider-direction-2" class="t-cn slider-direction">
                    <div class="slider-content s-tb slide-2">
                        <div class="title-container s-tb-c title-dark">
                            <div class="container text-right title-double-line">
                                <p class="slider-big-text">Pendataan Alumni SMP</p>
                                <p class="slider-sub-text para-padding-left">Silahkan daftar sebagai alumni smp ?, jika anda lulusan smp ?</p>
                                @if (Route::has('login'))
                                <div class="slider-btn-area slider-btn-left">
                                    <div class="top-right links">
                                            <a href="{{ route('login') }}" class="btn-ftf-rd-sm-p-dp">Login</a>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Slider Area End Here -->
        <!-- Service Area Start Here -->
        <section class="s-space-layout6 primary-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="service-title-light service-sub-title-light text-center mb-30">
                            <i class="flaticon-line-chart icon-default-light"></i>
                            <h3><a href="#">Web Analytics</a></h3>
                            <p>Tand typesetting istrykorem Ipsum hasbeen daandare scrambledmake a type specimenok .oremarea ipsum ipiscing diam dearty non.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="service-title-light service-sub-title-light text-center mb-30">
                            <i class="flaticon-targeting icon-default-light"></i>
                            <h3><a href="#">Target Keyword</a></h3>
                            <p>Tand typesetting istrykorem Ipsum hasbeen daandare scrambledmake a type specimenok .oremarea ipsum ipiscing diam dearty non.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="service-title-light service-sub-title-light text-center mb-30">
                            <i class="flaticon-mail icon-default-light"></i>
                            <h3><a href="#">Email Marketing</a></h3>
                            <p>Tand typesetting istrykorem Ipsum hasbeen daandare scrambledmake a type specimenok .oremarea ipsum ipiscing diam dearty non.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Service Area End Here -->
        <!-- About Area Start Here -->
        <section class="s-space-default bg-accent">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                        <div class="lead inner-title-dark mb45--xs">
                            <h2>Why You Need SEO?</h2>
                            <p>Rimply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since thprinter took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries the leap into electronic typesetting, remaining essentially unchanged.</p>
                            <a href="#" class="btn-ftf-rd-md-p-tp mt-30">See Menu</a>
                        </div>
                    </div>
                    <div class="text-center col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <img src="img/about/about7.png" class="img-responsive m-auto" alt="about">
                    </div>
                </div>
            </div>
        </section>
        <!-- About Area End Here -->
        <!-- Service Area Start Here -->
        <section class="s-space-layout1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="media mb-30">
                            <i class="flaticon-monitor-1 pull-left icon-default-primary"></i>
                            <div class="media-body">
                                <h3 class="service-title-dark"><a href="#">Responsive Design</a></h3>
                                <p>Hmply dummy text of the printingdeeiy aere tysetting industrorem Ipsdustry's standard dummy tsinpe bled.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="media mb-30">
                            <i class="flaticon-transport pull-left icon-default-primary"></i>
                            <div class="media-body">
                                <h3 class="service-title-dark"><a href="#">Awesome Features</a></h3>
                                <p>Hmply dummy text of the printingdeeiy aere tysetting industrorem Ipsdustry's standard dummy tsinpe bled.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="media mb-30">
                            <i class="flaticon-suitcase pull-left icon-default-primary"></i>
                            <div class="media-body">
                                <h3 class="service-title-dark"><a href="#">Strong Porfolio</a></h3>
                                <p>Hmply dummy text of the printingdeeiy aere tysetting industrorem Ipsdustry's standard dummy tsinpe bled.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="media mb-30">
                            <i class="flaticon-cart pull-left icon-default-primary"></i>
                            <div class="media-body">
                                <h3 class="service-title-dark"><a href="#">WooCommerce</a></h3>
                                <p>Hmply dummy text of the printingdeeiy aere tysetting industrorem Ipsdustry's standard dummy tsinpe bled.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="media mb-30">
                            <i class="flaticon-settings pull-left icon-default-primary"></i>
                            <div class="media-body">
                                <h3 class="service-title-dark"><a href="#">Settings</a></h3>
                                <p>Hmply dummy text of the printingdeeiy aere tysetting industrorem Ipsdustry's standard dummy tsinpe bled.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="media mb-30">
                            <i class="flaticon-two-speech-bubbles pull-left icon-default-primary"></i>
                            <div class="media-body">
                                <h3 class="service-title-dark"><a href="#">Social Media</a></h3>
                                <p>Hmply dummy text of the printingdeeiy aere tysetting industrorem Ipsdustry's standard dummy tsinpe bled.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Service Area End Here -->
        <!-- Counter Area Start Here -->
        <section class="s-space-layout1 overlay-default" style="background-image: url('img/counter/counter-back-12.jpg');">
            <div class="container">
                <div class="row">
                    <div class="counter-title item-mb col-lg-3 col-md-3 col-sm-3 col-xs-6 col-mb-12 wow fadeInDown" data-wow-duration=".5s" data-wow-delay=".20s">
                        <h3 class="counter" data-num="1520">1520</h3>
                        <h4>Satisfied Persons</h4>
                    </div>
                    <div class="counter-title item-mb col-lg-3 col-md-3 col-sm-3 col-xs-6 col-mb-12 wow fadeInDown" data-wow-duration=".5s" data-wow-delay=".40s">
                        <h3 class="counter" data-num="1160">1160</h3>
                        <h4>Successfull Works</h4>
                    </div>
                    <div class="counter-title item-mb col-lg-3 col-md-3 col-sm-3 col-xs-6 col-mb-12 wow fadeInDown" data-wow-duration=".5s" data-wow-delay=".60s">
                        <h3 class="counter" data-num="1905">1905</h3>
                        <h4>Received Awards</h4>
                    </div>
                    <div class="counter-title item-mb col-lg-3 col-md-3 col-sm-3 col-xs-6 col-mb-12 wow fadeInDown" data-wow-duration=".5s" data-wow-delay=".80s">
                        <h3 class="counter" data-num="1440">1440</h3>
                        <h4>Working Projects</h4>
                    </div>
                </div>
            </div>
        </section>
        <!-- Counter Area End Here -->
        <!-- Team Area Start Here -->
        <section class="s-space-default">
            <div class="container">
                <h2 class="section-title-dark">Our Expert Team</h2>
                <p class="section-sub-title-dark lead">Rimply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen standard daand scrambled</p>
            </div>
            <div class="container">
                <div class="rc-carousel nav-control-middle" data-loop="true" data-items="3" data-margin="30" data-autoplay="false" data-autoplay-timeout="10000" data-smart-speed="2000" data-dots="false" data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true" data-r-x-small-dots="false" data-r-x-medium="2" data-r-x-medium-nav="true" data-r-x-medium-dots="false" data-r-small="2" data-r-small-nav="true" data-r-small-dots="false" data-r-medium="3" data-r-medium-nav="true" data-r-medium-dots="false">
                    <div class="team-box-layout8">
                        <div class="item-img">
                            <figure>
                                <a href="#"><img src="img/team/team36.jpg" class="img-responsive img-circle" alt="team"></a>
                            </figure>
                        </div>
                        <div class="item-content">
                            <h3 class="team-title"><a href="single-team.html">David Smith</a></h3>
                            <div class="team-designation">SEO Analyst</div>
                            <p>Demply dummy text of the printing and typesetting industry. Lorem Ipsum stry's standard dummy text ever since printer galley.</p>
                            <ul class="team-social-fill">
                                <li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-box-layout8">
                        <div class="item-img">
                            <figure>
                                <a href="#"><img src="img/team/team37.jpg" class="img-responsive img-circle" alt="team"></a>
                            </figure>
                        </div>
                        <div class="item-content">
                            <h3 class="team-title"><a href="single-team.html">David Smith</a></h3>
                            <div class="team-designation">SEO Analyst</div>
                            <p>Demply dummy text of the printing and typesetting industry. Lorem Ipsum stry's standard dummy text ever since printer galley.</p>
                            <ul class="team-social-fill">
                                <li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team-box-layout8">
                        <div class="item-img">
                            <figure>
                                <a href="#"><img src="img/team/team38.jpg" class="img-responsive img-circle" alt="team"></a>
                            </figure>
                        </div>
                        <div class="item-content">
                            <h3 class="team-title"><a href="single-team.html">David Smith</a></h3>
                            <div class="team-designation">SEO Analyst</div>
                            <p>Demply dummy text of the printing and typesetting industry. Lorem Ipsum stry's standard dummy text ever since printer galley.</p>
                            <ul class="team-social-fill">
                                <li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Team Area End Here -->
        <!-- Banner Area Start Here -->
        <section class="s-space-default primary-bg" style="background-image: url('img/banner/banner1.png');">
            <div class="container">
                <h2 class="section-lg-title-light mb-40">Check Your Website’s SEO Problems For Free!</h2>
            </div>
            <div class="container">
                <form class="site-checking-form-area">
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-sm-4 col-xs-12 mb-xs">
                            <input type="text" class="form-control" placeholder="Type Your Website URL Here ..." name="name" id="form-name1" data-error="Subject field is required" required />
                        </div>
                        <div class="col-lg-5 col-md-5 col-sm-4 col-xs-12 mb-xs">
                            <input type="text" class="form-control" placeholder="Type Your E-mailL Here ..." name="name" id="form-name2" data-error="Subject field is required" required />
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center">
                            <a href="#" class="btn-ftg-rd-ms-tp-tr">Checkout</a>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <!-- Banner Area End Here -->
        <!-- Blog Area Start Here -->
        <section class="s-space-default bg-accent">
            <div class="container">
                <h2 class="section-title-dark">Latest Blog Posts</h2>
                <p class="section-sub-title-dark lead">Rimply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen standard daand scrambled</p>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 mb-xs-list">
                        <div class="blog-box-layout1">
                            <div class="item-img">
                                <a href="#"><img src="img/blog/blog31.jpg" alt="blog" class="img-responsive"></a>
                            </div>
                            <div class="item-content">
                                <ul class="published-date-dark">
                                    <li>15 June, 2016</li>
                                    <li>Business</li>
                                </ul>
                                <h3 class="blog-title"><a href="single-blog.html">Bnknown printer took a galley of type and scrambled type specimen book</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 mb-xs-list">
                        <div class="blog-box-layout1">
                            <div class="item-img">
                                <a href="#"><img src="img/blog/blog32.jpg" alt="blog" class="img-responsive"></a>
                            </div>
                            <div class="item-content">
                                <ul class="published-date-dark">
                                    <li>15 June, 2016</li>
                                    <li>Business</li>
                                </ul>
                                <h3 class="blog-title"><a href="single-blog.html">Bnknown printer took a galley of type and scrambled type specimen book</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 mb-xs-list">
                        <div class="blog-box-layout1">
                            <div class="item-img">
                                <a href="#"><img src="img/blog/blog33.jpg" alt="blog" class="img-responsive"></a>
                            </div>
                            <div class="item-content">
                                <ul class="published-date-dark">
                                    <li>15 June, 2016</li>
                                    <li>Business</li>
                                </ul>
                                <h3 class="blog-title"><a href="single-blog.html">Bnknown printer took a galley of type and scrambled type specimen book</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog Area End Here -->
        <!-- Brand Area Start Here -->
        <section class="s-space-brand">
            <div class="container">
                <div class="rc-carousel nav-control-middle" data-loop="true" data-items="6" data-margin="30" data-autoplay="true" data-autoplay-timeout="5000" data-smart-speed="2000" data-dots="false" data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true" data-r-x-small-dots="false" data-r-x-medium="3" data-r-x-medium-nav="true" data-r-x-medium-dots="false" data-r-small="4" data-r-small-nav="true" data-r-small-dots="false" data-r-medium="6" data-r-medium-nav="true" data-r-medium-dots="false">
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand1.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand2.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand3.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand4.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand5.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand6.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand1.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand2.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand3.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand4.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand5.png" alt="brand"></a>
                    </div>
                    <div class="brand-box">
                        <a href="#"><img src="img/brand/brand6.png" alt="brand"></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Brand Area End Here -->
        <!-- Footer Area Start Here -->
        <footer>
            <div class="footer-area-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box">
                                <div class="footer-logo">
                                    <a href="index.html" class="logo-light"><span>E</span> ELVIS</a>
                                </div>
                                <div class="footer-about">
                                    <p>Praesent vel rutrum purus. Nam vel dui eu risus duis dignissim dignissim area Suspen derocongueconsequat.Fusce sit amet urna iat.Praesent vel rutrum purus. Nam vel dui eu risus.</p>
                                </div>
                                <ul class="footer-social">
                                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box">
                                <h3 class="title-bar-footer">Recent Posts</h3>
                                <ul class="recent-post-link">
                                    <li><a href="#">Standard Blog post</a></li>
                                    <li><a href="#">Quotation post</a></li>
                                    <li><a href="#">Audio Post</a></li>
                                    <li><a href="#">AwesomeDemo</a></li>
                                    <li><a href="#">Blog Post</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box">
                                <h3 class="title-bar-footer">Quick Links</h3>
                                <ul class="quick-link">
                                    <li><a href="#">About Elvis</a></li>
                                    <li><a href="#">Career</a></li>
                                    <li><a href="#">Terms & Condition</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box">
                                <h3 class="title-bar-footer">Instagram</h3>
                                <ul class="flickr-photos">
                                    <li>
                                        <a href="#"><img class="img-responsive" src="img/footer/1.jpg" alt="Instagram"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img class="img-responsive" src="img/footer/2.jpg" alt="Instagram"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img class="img-responsive" src="img/footer/3.jpg" alt="Instagram"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img class="img-responsive" src="img/footer/4.jpg" alt="Instagram"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img class="img-responsive" src="img/footer/5.jpg" alt="Instagram"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img class="img-responsive" src="img/footer/6.jpg" alt="Instagram"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-area-bottom">
                <div class="container">
                    <p>&copy; 2017 Elvis All Rights Reserved. Designed by<a target="_blank" href="https://radiustheme.com/"> RadiusTheme</a>.com</p>
                </div>
            </div>
        </footer>
        <!-- Footer Area End Here -->
    </div>
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <!-- scrollToTop Start Here -->
    <a href="#" class="scrollToTop"></a>
    <!-- scrollToTop End Here -->
    <!-- jquery-->
    <script src="../js/jquery-2.2.4.min.js" type="text/javascript"></script>
    <!-- Plugins js -->
    <script src="../js/plugins.js" type="text/javascript"></script>
    <!-- Bootstrap js -->
    <script src="../js/bootstrap.min.js" type="text/javascript"></script>
    <!-- WOW JS -->
    <script src="../js/wow.min.js"></script>
    <!-- Nivo slider js -->
    <script src="../vendor/slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
    <script src="../vendor/slider/home.js" type="text/javascript"></script>
    <!-- Owl Cauosel JS -->
    <script src="../vendor/OwlCarousel/owl.carousel.min.js" type="text/javascript"></script>
    <!-- Silk Cauosel JS -->
    <script src="../vendor/slick/slick.min.js" type="text/javascript"></script>
    <!-- Meanmenu Js -->
    <script src="../js/jquery.meanmenu.min.js" type="text/javascript"></script>
    <!-- Srollup js -->
    <script src="../js/jquery.scrollUp.min.js" type="text/javascript"></script>
    <!-- jquery.counterup js -->
    <script src="../js/jquery.counterup.min.js"></script>
    <script src="../js/waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="../js/isotope.pkgd.min.js" type="text/javascript"></script>
    <!--Magnific Popup-->
    <script src="../js/jquery.magnific-popup.min.js"></script>
    <!-- Switch js -->
    <script src="../js/switch-style.js" type="text/javascript"></script>
    <!-- Select2 Js -->
    <script src="../js/select2.min.js" type="text/javascript"></script>
    <!-- Custom Js -->
    <script src="../js/main.js" type="text/javascript"></script>
</body>


<!-- Mirrored from www.radiustheme.com/demo/html/elvis/elvis/multi-page/index16.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Nov 2019 16:26:42 GMT -->
</html>
