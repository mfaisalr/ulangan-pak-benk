<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('user_id')->unsigned()->index()->unique();
            $table->string('full_name');
            $table->string('graduation_year')->nullable();
            $table->bigInteger('religion_id')->unsigned()->index()->unique();
            $table->string('address');
            $table->string('phone_number')->unique();
            $table->string('facebook')->unique();
            $table->string('instagram')->unique();
            $table->string('job');
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users');
            $table->foreign('religion_id')->references('id')->on('religions');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profiles');
    }
}
